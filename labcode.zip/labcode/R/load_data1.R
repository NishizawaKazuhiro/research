rm(list = ls())

# see https://groups.google.com/forum/#!topic/monocle-users/sTq8vYyJA78
# when you have a problem

#loading monocle library
library(monocle)

library("igraph", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.4")
library("pkgconfig", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.4")


#read the data files
HSMM_expr_matrix <- read.table("/home/nishizawa/Desktop/file/article/cencus/testdata/test/data/total_fpkm_matrix.txt",header = TRUE,row.names=1)
HSMM_sample_sheet <- read.delim("/home/nishizawa/Desktop/file/article/cencus/testdata/test/data/celltest_sample_sheet.txt",sep=",",row.names=1)
HSMM_gene_annotation <- read.delim("/home/nishizawa/Desktop/file/article/cencus/testdata/test/data/gene_annotations.txt",sep=",",row.names=1)

#Create Cell dataset
pd <- new("AnnotatedDataFrame", data = HSMM_sample_sheet)
fd <- new("AnnotatedDataFrame", data = HSMM_gene_annotation)
# when you use newCellDataSet you should install "igraph" and "pkgconfig" first.
HSMM <- newCellDataSet(as.matrix(HSMM_expr_matrix), phenoData = pd, featureData = fd)

# make RPC data from TPM value
pd <- new("AnnotatedDataFrame", data = HSMM_sample_sheet)
fd <- new("AnnotatedDataFrame", data = HSMM_gene_annotation)
# First create a CellDataSet from the relative expression levels
HSMM <- newCellDataSet(as.matrix(HSMM_expr_matrix),
                       phenoData = pd,
                       featureData = fd,
                       lowerDetectionLimit=0.1,
                       expressionFamily=tobit(Lower=0.1))

# Next, use it to estimate RNA counts
rpc_matrix <- relative2abs(HSMM)

write.csv(rpc_matrix, "/home/nishizawa/Desktop/file/article/cencus/testdata/test/data/total_article_rpc_matrix.csv", row.names=TRUE, quote=TRUE)
# Now, make a new CellDataSet using the RNA counts
HSMM <- newCellDataSet(as(as.matrix(rpc_matrix), "sparseMatrix"),
                       phenoData = pd,
                       featureData = fd,
                       lowerDetectionLimit=0.5,
                       expressionFamily=negbinomial.size())

HSMM <- estimateSizeFactors(HSMM)
HSMM <- estimateDispersions(HSMM)

HSMM <- detectGenes(HSMM, min_expr = 0.1)
print(head(fData(HSMM)))

HSMM <- detectGenes(HSMM, min_expr = 0.1)
print(head(fData(HSMM)))
expressed_genes <- row.names(subset(fData(HSMM),
                                    num_cells_expressed >= 10))

print(head(pData(HSMM)))

valid_cells <- row.names(subset(pData(HSMM)))
HSMM <- HSMM[,valid_cells]

pData(HSMM)$Total_mRNAs <- Matrix::colSums(exprs(HSMM))

HSMM <- HSMM[,pData(HSMM)$Total_mRNAs < 1e6]

upper_bound <- 10^(mean(log10(pData(HSMM)$Total_mRNAs)) +
                     2*sd(log10(pData(HSMM)$Total_mRNAs)))
lower_bound <- 10^(mean(log10(pData(HSMM)$Total_mRNAs)) -
                     2*sd(log10(pData(HSMM)$Total_mRNAs)))

qplot(Total_mRNAs, data = pData(HSMM), color = Date, geom =
        "density") +
  geom_vline(xintercept = lower_bound) +
  geom_vline(xintercept = upper_bound)

HSMM <- HSMM[,pData(HSMM)$Total_mRNAs > lower_bound &
               pData(HSMM)$Total_mRNAs < upper_bound]
HSMM <- detectGenes(HSMM, min_expr = 0.1)

# Log-transform each value in the expression matrix.
#L <- log(rpc_matrix)
L <- log(exprs(HSMM[expressed_genes,]))

# Standardize each gene, so that they are all on the same scale,
# Then melt the data with plyr so we can plot it easily
library(reshape2)
library(plyr)
melted_dens_df <- melt(Matrix::t(scale(Matrix::t(L))))

# Plot the distribution of the standardized gene expression values.
qplot(value, geom = "density", data = melted_dens_df) +
  stat_function(fun = dnorm, size = 0.5, color = 'red') +
  xlab("Standardized log(FPKM)") +
  ylab("Density")


