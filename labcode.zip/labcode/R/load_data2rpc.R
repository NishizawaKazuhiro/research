## Clasify Cell

Gene1_id <- row.names(subset(fData(rpc_matrix), gene_short_name == "gene1"))
Gene2_id <- row.names(subset(fData(rpc_matrix),
                             gene_short_name == "gene2"))

cth <- newCellTypeHierarchy()
cth <- addCellType(cth, "Gene1", classify_func =
                     function(x) { x[Gene1_id,] >= 1 })
cth <- addCellType(cth, "Gene2", classify_func = function(x)
{ x[Gene1_id,] < 1 & x[Gene2_id,] > 1 })

rpc_matrix <- classifyCells(rpc_matrix, cth, 0.1)

table(pData(rpc_matrix)$CellType)

pie <- ggplot(pData(rpc_matrix),
              aes(x = factor(1), fill = factor(CellType))) + geom_bar(width = 1)
pie + coord_polar(theta = "y") +
  theme(axis.title.x = element_blank(), axis.title.y = element_blank())

disp_table <- dispersionTable(rpc_matrix)
unsup_clustering_genes <- subset(disp_table, mean_expression >= 0.1)
rpc_matrix<- setOrderingFilter(rpc_matrix, unsup_clustering_genes$gene_id)
plot_ordering_genes(rpc_matrix)
## Clustering cells without marker genes 

disp_table <- dispersionTable(rpc_matrix)
unsup_clustering_genes <- subset(disp_table, mean_expression >= 0.1)
rpc_matrix <- setOrderingFilter(rpc_matrix, unsup_clustering_genes$gene_id)
plot_ordering_genes(rpc_matrix)

# HSMM@auxClusteringData[["tSNE"]]$variance_explained <- NULL
plot_pc_variance_explained(rpc_matrix, return_all = F) # norm_method='log'

X.pca <- prcomp(rpc_matrix, scale=TRUE)
summary(X.pca)
screeplot(X.pca, main="Screeplot for Variance")
abline(h=1, lty=2)
library(psych)
fa.parallel(rpc_matrix)

rpc_matrix <- reduceDimension(rpc_matrix, max_components = 2, num_dim = 6,
                        reduction_method = 'tSNE', verbose = T)
rpc_matrix <- clusterCells(rpc_matrix, num_clusters = 2)
plot_cell_clusters(rpc_matrix, 1, 2, color = "Date",
                   markers = c("MYF5", "ANPEP"))


HSMM <- reduceDimension(HSMM, max_components = 2, num_dim = 6,
                        reduction_method = 'tSNE', verbose = T)
HSMM <- clusterCells(HSMM, num_clusters = 2)
plot_cell_clusters(HSMM, 1, 2, color = "Date",
                   markers = c("MYF5", "ANPEP"))

plot_cell_clusters(HSMM, 1, 2, color = "Date")


HSMM <- reduceDimension(HSMM, max_components = 2, num_dim = 2,
                        reduction_method = 'tSNE',
                        residualModelFormulaStr = "~Media + num_genes_expressed",
                        verbose = T)
HSMM <- clusterCells(HSMM, num_clusters = 2)
plot_cell_clusters(HSMM, 1, 2, color = "CellType")

HSMM <- clusterCells(HSMM, num_clusters = 2)
plot_cell_clusters(HSMM, 1, 2, color = "Cluster") +
  facet_wrap(~CellType)


## Clustering cells using marker genes 

marker_diff <- markerDiffTable(HSMM[expressed_genes,],
                               cth,
                               residualModelFormulaStr = "~Media + num_genes_expressed",
                               cores = 1)

candidate_clustering_genes <-
  row.names(subset(marker_diff, qval < 0.01))
marker_spec <-
  calculateMarkerSpecificity(HSMM[candidate_clustering_genes,], cth)
head(selectTopMarkers(marker_spec, 3))

semisup_clustering_genes <- unique(selectTopMarkers(marker_spec, 500)$gene_id)
HSMM <- setOrderingFilter(HSMM, semisup_clustering_genes)
plot_ordering_genes(HSMM)

plot_pc_variance_explained(HSMM, return_all = F)

HSMM <- reduceDimension(HSMM, max_components = 100, num_dim = 3,
                        norm_method = 'log',
                        reduction_method = 'tSNE',
                        residualModelFormulaStr = "~Date + num_genes_expressed",
                        verbose = T)
HSMM <- clusterCells(HSMM, num_clusters = 2)
plot_cell_clusters(HSMM, 1, 2, color = "CellType")


HSMM <- clusterCells(HSMM,
                     num_clusters = 2,
                     frequency_thresh = 0.1,
                     cell_type_hierarchy = cth)
plot_cell_clusters(HSMM, 1, 2, color = "CellType",
                   markers = c("MYF5", "ANPEP"))
